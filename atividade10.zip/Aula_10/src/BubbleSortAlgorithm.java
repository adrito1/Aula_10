class BubbleSortAlgorithm {
    public int[] sort(int[] numbers) {
        int[] sortedNumbers = numbers.clone();
        
        for (int n = 1; n <= sortedNumbers.length; n++) {
            for (int i = 0; i < sortedNumbers.length - 1; i++) {
                if (sortedNumbers[i] > sortedNumbers[i + 1]) {
                    int temp = sortedNumbers[i];
                    sortedNumbers[i] = sortedNumbers[i + 1];
                    sortedNumbers[i + 1] = temp;
                }
            }
        }
        
        return sortedNumbers;
    }
}