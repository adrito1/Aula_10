import java.util.Scanner;

class InputHandler {
    public int[] getInput() {
        Scanner in = new Scanner(System.in);
        int[] inputNumbers = new int[10];
        
        System.out.println("Digite 10 números:");
        for (int i = 0; i < inputNumbers.length; i++) {
            System.out.println("Digite o " + (i + 1) + "º número:");
            inputNumbers[i] = in.nextInt();
        }
        
        return inputNumbers;
    }
}