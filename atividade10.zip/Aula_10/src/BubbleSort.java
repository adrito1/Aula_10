import java.util.Scanner;

public class BubbleSort {
    public static void main(String[] args) {
        InputHandler inputHandler = new InputHandler();
        int[] numbers = inputHandler.getInput();
        
        BubbleSortAlgorithm bubbleSort = new BubbleSortAlgorithm();
        int[] sortedNumbers = bubbleSort.sort(numbers);
        
        System.out.println("Números ordenados:");
        for (int i = 0; i < sortedNumbers.length; i++) {
            System.out.println((i + 1) + "º número: " + sortedNumbers[i]);
        }
    }
}